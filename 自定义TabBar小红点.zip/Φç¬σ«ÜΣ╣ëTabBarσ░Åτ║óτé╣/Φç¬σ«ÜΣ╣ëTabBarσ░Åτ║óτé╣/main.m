//
//  main.m
//  自定义TabBar小红点
//
//  Created by laidongling on 17/7/11.
//  Copyright © 2017年 LaiDongling. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
