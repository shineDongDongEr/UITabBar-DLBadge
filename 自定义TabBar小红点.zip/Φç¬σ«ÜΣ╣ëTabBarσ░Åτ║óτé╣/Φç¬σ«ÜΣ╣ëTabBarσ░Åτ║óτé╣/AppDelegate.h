//
//  AppDelegate.h
//  自定义TabBar小红点
//
//  Created by laidongling on 17/7/11.
//  Copyright © 2017年 LaiDongling. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

