//
//  ViewController.m
//  自定义TabBar小红点
//
//  Created by laidongling on 17/7/11.
//  Copyright © 2017年 LaiDongling. All rights reserved.

#import "ViewController.h"
#import "UITabBar+DLBadge.h"
#import <objc/runtime.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITabBar *myTabBar;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self showRedPoint];
    [self test];        //此处只用于调试，具体项目使用可省略！！！
    
}

//显示小红点
- (void)showRedPoint
{
    self.myTabBar.badgeSize = CGSizeMake(14, 14);           //不设置默认为12
    self.myTabBar.badgeColor = [UIColor orangeColor];       //不设置默认为红色
    self.myTabBar.badgeImage = [UIImage imageNamed:@"补贴"]; //不设置只显示小红点
    //！！！最重要的一句代码
    [self.myTabBar showBadgeOnItemIndex:2];                 //传入你所需要显示红点的index即可显示，此处demo点击屏幕，红点消失

}

- (void)test
{
   NSMutableArray *methodList = [self getAllMethods:[UITabBarItem class]];
   NSLog(@"%@",methodList);

}

//运行时获取类（用于调试，可不引入项目！）
- (NSMutableArray *)getAllMethods:(Class)cls
{
    unsigned int outCount_f ;
    Method *methods = class_copyMethodList(cls, &outCount_f);
    NSMutableArray *mArray = [NSMutableArray array];
    for (int i = 0; i < outCount_f; i++)
    {
        Method temp_f = methods[i];
        const char *m_name = sel_getName(method_getName(temp_f));
        [mArray addObject:[NSString stringWithUTF8String:m_name]];
    }
    return mArray;
}

//运行时获取类的所有属性（用于调试，可不引入项目！）
- (NSMutableArray *)getProperties:(Class)cls
{
    unsigned int count;
    NSMutableArray *mArray = [NSMutableArray array];
    //运行时获取属性列表
    objc_property_t *properties = class_copyPropertyList(cls, &count);
    for (int i = 0; i < count; i++)
    {
        objc_property_t property = properties[i];
        const char *cName = property_getName(property);
        NSString *name = [NSString stringWithUTF8String:cName];
        [mArray addObject:name];
    }
    return mArray;
}

//点击屏幕消失
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.myTabBar hiddenRedPointOnIndex:2 animation:YES];
}



@end
