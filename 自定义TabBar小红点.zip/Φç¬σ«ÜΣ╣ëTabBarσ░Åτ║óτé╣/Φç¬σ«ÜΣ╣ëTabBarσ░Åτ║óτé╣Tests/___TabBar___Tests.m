//
//  ___TabBar___Tests.m
//  自定义TabBar小红点Tests
//
//  Created by laidongling on 17/7/11.
//  Copyright © 2017年 LaiDongling. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ___TabBar___Tests : XCTestCase

@end

@implementation ___TabBar___Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
